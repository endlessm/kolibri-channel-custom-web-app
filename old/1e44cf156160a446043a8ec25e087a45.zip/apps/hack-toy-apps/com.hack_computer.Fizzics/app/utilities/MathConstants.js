	

var ZERO     	= 0.0;
var ONE_HALF 	= 0.5;
var ONE		 	= 1.0;
var PI2 		= Math.PI * 2.0;
var PI_OVER_180 = Math.PI / 180.0;
var MILLISECONDS_PER_SECOND = 1000;

